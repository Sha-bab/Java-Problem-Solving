class Animal {
    String name;

    Animal(String name) {
        this.name = name;
    }

    void eat() {
        System.out.println(name + " is eating.");
    }
}

class Mammal extends Animal {
    int legs;

    Mammal(String name, int legs) {
        super(name);
        this.legs = legs;
    }

    void walk() {
        System.out.println(name + " is walking on " + legs + " legs.");
    }
}

class Dog extends Mammal {
    String breed;

    Dog(String name, int legs, String breed) {
        super(name, legs);
        this.breed = breed;
    }

    void bark() {
        System.out.println(name + " the " + breed + " is barking.");
    }
}

public class Main {
    public static void main(String[] args) {
        Dog myDog = new Dog("Buddy", 4, "Golden Retriever");

        myDog.eat();
        myDog.walk();
        myDog.bark();
    }
}
