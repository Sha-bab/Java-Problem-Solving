class BaseClass {
    final void finalMethod() {
        System.out.println("BaseClass finalMethod");
    }

    void normalMethod(){
        System.out.println("BaseClass normalMethod");
    }
}

final class FinalClass {
    void display() {
        System.out.println("FinalClass display");
    }
}

// class DerivedClass extends FinalClass { // This will cause a compile-time error
// }

class DerivedClass extends BaseClass {
    // void finalMethod() { // This will cause a compile-time error
    //     System.out.println("DerivedClass finalMethod");
    // }

    @Override
    void normalMethod(){
        System.out.println("DerivedClass normalMethod");
    }
}

public class Main {
    public static void main(String[] args) {
        BaseClass base = new BaseClass();
        base.finalMethod();
        base.normalMethod();

        DerivedClass derived = new DerivedClass();
        derived.normalMethod();

        FinalClass finalClass = new FinalClass();
        finalClass.display();
    }
}