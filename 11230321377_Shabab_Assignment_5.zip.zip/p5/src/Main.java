class Person {
    String name;

    Person(String name) {
        this.name = name;
    }

    void display() {
        System.out.println("Name: " + name);
    }
}

class Employee extends Person {
    int id;

    Employee(String name, int id) {
        super(name);
        this.id = id;
    }

    void display() {
        super.display();
        System.out.println("Employee ID: " + id);
    }
}

public class Main {
    public static void main(String[] args) {
        Employee e = new Employee("John", 101);
        e.display();
    }
}
