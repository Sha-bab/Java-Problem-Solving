// Parent class
class Animal {
    String name;

    // Constructor
    Animal(String name) {
        this.name = name;
    }

    // Method to display general animal behavior
    void makeSound() {
        System.out.println(name + " makes a sound.");
    }
}

class Dog extends Animal {
    String breed;

    Dog(String name, String breed) {
        super(name); // Calls the parent class constructor
        this.breed = breed;
    }

    @Override
    void makeSound() {
        System.out.println(name + " (a " + breed + ") barks.");
    }

    void wagTail() {
        System.out.println(name + " is wagging its tail.");
    }
}


public class Main {
    public static void main(String[] args) {
        Dog myDog = new Dog("Buddy", "Golden Retriever");

        myDog.makeSound();
        myDog.wagTail();

        // Demonstrating access to parent class members
        System.out.println("Name: " + myDog.name);
    }
}
