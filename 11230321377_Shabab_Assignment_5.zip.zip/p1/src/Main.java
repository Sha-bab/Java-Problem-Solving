
class Animal {
    String name;
    int age;


    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }


    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age + " years");
    }
}


class Dog extends Animal {


    public Dog(String name, int age) {
        super(name, age); // Calling superclass constructor
    }


    public void bark() {
        System.out.println(name + " is barking: Woof! Woof!");
    }
}

public class Main {
    public static void main(String[] args) {
        // Creating an object of Dog
        Dog myDog = new Dog("Buddy", 3);


        myDog.displayInfo();


        myDog.bark();
    }
}