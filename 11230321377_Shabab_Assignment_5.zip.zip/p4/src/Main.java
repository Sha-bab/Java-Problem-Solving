class Parent {
    private int privateVar = 10;
    protected int protectedVar = 20;
    public int publicVar = 30;

    void display() {
        System.out.println("Private: " + privateVar);
        System.out.println("Protected: " + protectedVar);
        System.out.println("Public: " + publicVar);
    }
}

class Child extends Parent {
    void show() {
        // System.out.println("Private: " + privateVar); // Not accessible
        System.out.println("Protected: " + protectedVar);
        System.out.println("Public: " + publicVar);
    }
}

public class Main {
    public static void main(String[] args) {
        Child c = new Child();
        c.show();

        Parent p = new Parent();
        // System.out.println(p.privateVar); // Not accessible
        // System.out.println(p.protectedVar); // Not accessible outside subclass
        System.out.println(p.publicVar);
    }
}
