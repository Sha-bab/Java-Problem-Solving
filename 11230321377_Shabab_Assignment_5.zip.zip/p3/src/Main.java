
class Vehicle {
    void move() {
        System.out.println("Vehicle is moving.");
    }
}

class Car extends Vehicle {
    @Override
    void move() {
        System.out.println("Car is driving on the road.");
    }
}

public class Main {
    public static void main(String[] args) {
        Vehicle v = new Vehicle();
        v.move();

        Car c = new Car();
        c.move();

        Vehicle vc = new Car();
        vc.move();
    }
}
