abstract class BankAccount {
    double balance;

    BankAccount(double balance) {
        this.balance = balance;
    }

    abstract void calculateInterest();
}

class SavingsAccount extends BankAccount {
    double interestRate;

    SavingsAccount(double balance, double interestRate) {
        super(balance);
        this.interestRate = interestRate;
    }

    @Override
    void calculateInterest() {
        double interest = balance * interestRate / 100;
        System.out.println("Interest for Savings Account: " + interest);
    }
}

class CurrentAccount extends BankAccount {
    double overdraftLimit;

    CurrentAccount(double balance, double overdraftLimit) {
        super(balance);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    void calculateInterest() {
        double interest = balance * 0.05; // Fixed interest rate for current accounts
        System.out.println("Interest for Current Account: " + interest);
    }
}

public class Main {
    public static void main(String[] args) {
        BankAccount savings = new SavingsAccount(1000, 4.5);
        savings.calculateInterest();

        BankAccount current = new CurrentAccount(2000, 500);
        current.calculateInterest();
    }
}
