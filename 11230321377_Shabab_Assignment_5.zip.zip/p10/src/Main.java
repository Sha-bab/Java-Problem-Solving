class Student {
    private String name;
    private int rollNumber;

    public Student(String name, int rollNumber) {
        this.name = name;
        this.rollNumber = rollNumber;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Roll Number: " + rollNumber;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Student student = (Student) obj;
        return rollNumber == student.rollNumber && name.equals(student.name);
    }


    public static void main(String[] args) {
        Student student1 = new Student("Alice", 123);
        Student student2 = new Student("Alice", 123);
        Student student3 = new Student("Bob", 456);

        System.out.println(student1.toString());
        System.out.println(student2.toString());
        System.out.println(student3.toString());

        System.out.println("student1 equals student2: " + student1.equals(student2));
        System.out.println("student1 equals student3: " + student1.equals(student3));

        Object obj = new Student("Charlie",789);
        System.out.println(obj.toString());
        System.out.println(student1.getClass());
        System.out.println(obj.getClass());

    }
}